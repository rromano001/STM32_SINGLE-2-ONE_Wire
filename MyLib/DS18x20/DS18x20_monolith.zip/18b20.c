/*
 * 18b20.c
 *
 *  Created on: Mar 19, 2020
 *      Author: roberto-mint
 *
 *      Mar 22 added ore function to manage RX TX data (HAL seem fail on large buffers?? )
 *      Mar 21 Changing functions to reduce code footptint
 *      Mar 19 start project
 */

#include "main.h"
#ifdef USE_FREERTOS
#include "cmsis_os.h"
#endif

#include "18b20.h"
#include <string.h>

#define DIRECT_OWCALLBAK 1
#define OWD_RX	0
#define OWD_TX	1

/*
 * USART2(Tx=D5 Rx=D6)
 */


typedef struct
	{
    volatile uint8_t Main_SM;              //Communication Phase 1: Main_SM
    volatile uint8_t ROM_SM;        //Communication Phase 2: Rom State Machine
    volatile uint8_t Function_SM;   //Communication Phase 3: DS function State Machine
    volatile uint8_t *ROM_TxBuffer;	// Buffer for ROM codes requiring transmit some data (ROM)
    volatile uint8_t *ROM_RxBuffer;	// Buffer for ROM codes requiring receive some data
    volatile uint8_t ROM_TxCount;	// number of byte to transmit
    volatile uint8_t ROM_RxCount;	// number of byte to be received
    volatile uint8_t *Function_TxBuffer;	// Buffer for Funct codes requiring transmit some data
    volatile uint8_t *Function_RxBuffer;	// Buffer for Funct codes requiring receive some data
    volatile uint8_t Function_TxCount;	// number of byte to transmit
    volatile uint8_t Function_RxCount;	// number of byte to be received
    volatile uint8_t ROM_CmdCode;        // Communication Phase 2: Rom code
    volatile uint8_t Function_CmdCode;   // Communication Phase 3: DS function code
    volatile uint8_t DataReady;			// set when data is ready on scratchpad
    volatile uint8_t NoDevice;			// Set When no device answer with presence pulse
	} State;
State state;

uint8_t internal_Buffer_rx[80];
uint8_t internal_Buffer_tx[80];
typedef struct
	{
		void(*OnComplete)(void);
		void(*OnErr)(void);
	}OneWire_Callback;

volatile OneWire_Callback onewire_callback;

volatile uint8_t TempRdy =0;
volatile uint8_t OW_BSend =0;
static	uint8_t OWB_index=0;
static  uint8_t OWB_Len;
static  uint8_t OWB_Dir;
volatile  uint8_t *OWB_BufferPtr;

// Header declaration
void StateMachine(void);
void OneWire_SetCallback(void(*OnComplete)(void), void(*OnErr)(void));
uint8_t ROMStateMachine(void);
uint8_t FunctionStateMachine(void);
void OW_DoRTXBuffer(void);
void OW_RTXByte(uint8_t val); //, uint16_t len) byte has fixed len 8
void OW_RTX(uint16_t len);

/* 1 - Wait end of transmission */
//while (ubTransmissionComplete != 1){}
/* Disable DMA1 Tx Channel */
//LL_DMA_DisableChannel(DMA1, LL_DMA_CHANNEL_2);

/* 2 - Wait end of reception */
//while (ubReceptionComplete != 1){}
/* Disable DMA1 Rx Channel */
//LL_DMA_DisableChannel(DMA1, LL_DMA_CHANNEL_3);


#ifndef DIRECT_OWCALLBAK
void OneWire_TxCpltCallback()
#else
/**
  * @brief  Function called from DMA1 IRQ Handler when Tx transfer is completed
  * @param  None
  * @retval None
  */
void DMA1_TransmitComplete_Callback(void)
//#endif
{
	/* DMA Tx transfer completed */
	/* Disable DMA1 Tx Channel */
	LL_DMA_DisableChannel(DMA1, LL_DMA_CHANNEL_2);
}
#endif

#ifndef DIRECT_OWCALLBAK
void OneWire_RxCpltCallback(void)
#else
/**
  * @brief  Function called from DMA1 IRQ Handler when Rx transfer is completed
  * @param  None
  * @retval None
  */
void DMA1_ReceiveComplete_Callback(void)
#endif
{
	  /* DMA Rx transfer completed */
	/* Disable DMA1 Rx Channel */
	LL_DMA_DisableChannel(DMA1, LL_DMA_CHANNEL_3);
	if(!OW_BSend)	// Skip on multiple byte send (HAL Bug??)
		StateMachine();
	else
		OW_DoRTXBuffer();
}


 /* OneWire_SendBytes & OneWire_ReadBytes */

void OneWire_SetCallback(void(*OnComplete)(void), void(*OnErr)(void))
{
	onewire_callback.OnErr = OnErr;
	onewire_callback.OnComplete = OnComplete;
}

uint8_t	FunctionBuffer[32];
uint8_t	ROMBuffer[32];

void DS18x20_OnComplete(void)
{

}

void DS18x20_Error(void)
{

}

uint8_t TM_OneWire_CRC8(uint8_t *addr, uint8_t len) {
	uint8_t crc = 0, inbyte, i, mix;

	while (len--) {
		inbyte = *addr++;
		for (i = 8; i; i--) {
			mix = (crc ^ inbyte) & 0x01;
			crc >>= 1;
			if (mix) {
				crc ^= 0x8C;
			}
			inbyte >>= 1;
		}
	}

	/* Return calculated CRC */
	return crc;
}

uint8_t DSCRC_OK(void)
{
	if (FunctionBuffer[8]==TM_OneWire_CRC8(FunctionBuffer,8))
		return(1);
	return(0);
}

int readtempds18s20(uint8_t sensnum)
{
	// 1 fractional bit
	return (100*(FunctionBuffer[1]*0x100+FunctionBuffer[0])/2);
}

int readtempds18b20(uint8_t sensnum)
{
	// 4 fractional bit
	return (100*(FunctionBuffer[1]*0x100+FunctionBuffer[0])/16);
}

void OneWire_Init()
{
	OneWire_UARTInit(9600);
	//HAL_NVIC_EnableIRQ(USART1_IRQn);
	//HAL_NVIC_DisableIRQ(USART1_IRQn);

}

// Declare a USART_HandleTypeDef handle structure.
void OneWire_UARTInit(uint32_t baudRate)
{
	LL_USART_Disable(OWHUART);
//	OWHUART.Instance=UART4; // USART2;
	 LL_USART_SetBaudRate(OWHUART, SystemCoreClock, LL_USART_OVERSAMPLING_16, baudRate);
//	OWHUART.Init.BaudRate = baudRate;
/*    OWHUART.Init.WordLength = UART_WORDLENGTH_8B;
    OWHUART.Init.StopBits = UART_STOPBITS_1;
    OWHUART.Init.Parity = UART_PARITY_NONE;
    OWHUART.Init.Mode = UART_MODE_TX_RX;
    OWHUART.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    OWHUART.Init.OverSampling = UART_OVERSAMPLING_16;
    */
//    HAL_UART_Init(&OWHUART);
//    HAL_HalfDuplex_Init(&OWHUART);
	  LL_USART_Enable(OWHUART);
}

void SnglWireFullDuplex_EnableRTX(void)	//UART_HandleTypeDef *huart)
{
  /* Enable the USART's transmit and receive interface by setting the TE bit in the USART CR1 register */
 // SET_BIT(huart->Instance->CR1, (USART_CR1_TE | USART_CR1_RE));
}


void HAL_SnglWireFullDuplex_DisableRTX(void)	//UART_HandleTypeDef *huart)
{
  /* Disable both Receive and transmit by Clearing TE and RE bits */
 // CLEAR_BIT(huart->Instance->CR1, (USART_CR1_TE | USART_CR1_RE));
}

uint8_t	OW_Buffer2Byte(void)
{
	uint8_t rvalue=0;
	for (uint8_t i=0;i<8;i++)
	{
		if(internal_Buffer_rx[i]>= 0xfe)
			rvalue |=1<<i;	// set bit to 1
		// ((internal_Buffer_rx[i*8+j]==0xff)?0x01:0x00)<<j);
		//rvalue <<= 1;	// shift right
	}
	return(rvalue);
}

void OW_SetRTXBuffer(volatile uint8_t *buffer, uint8_t len, uint8_t dir)
{
	OWB_index=0;	// init buffer indexer
	OWB_Len= len;	// set Transfer len
	OWB_Dir = dir;	// Set RX or tx mode
	OWB_BufferPtr=buffer;	// Set buffer pointer to actual buffer
	OW_DoRTXBuffer();	// start transfer
}

void OW_DoRTXBuffer(void)
{
	if(OWB_Dir==OWD_TX)
		OW_RTXByte(OWB_BufferPtr[OWB_index]);	// tx buffer
	else
	{
		OW_RTXByte(0xff);	// tx 0xff to receive back data
		if(OW_BSend)	// Skip first time need transmit only then receive
			OWB_BufferPtr[OWB_index-1]=	OW_Buffer2Byte();	// convert received string to byte, store
	}
	if (!OWB_index&&!OW_BSend)
		OW_BSend=1;	// return here till last OWByte
	if (++OWB_index>OWB_Len)
	{
		OW_BSend =0;	// terminate transfer loop
		StateMachine();	// execute state machine on last byte
	}
}

void OW_RTXByte(uint8_t val) //, uint16_t len) byte has fixed len 8
{
	for (uint8_t i=0;i<8;i++)
		internal_Buffer_tx[i]=((val>>i)&0x01)?0xff:0x00;
	OW_RTX(8);
//	HAL_UART_Receive_IT(&OWHUART,&(internal_Buffer_rx[0]),8); //len);
//	HAL_UART_Transmit_IT(&OWHUART,&(internal_Buffer_tx[0]),8); //len);
}

void OW_RTX(uint16_t len)
{/*
	HAL_UART_Receive_IT(&OWHUART,&(internal_Buffer_rx[0]),len);
	HAL_UART_Transmit_IT(&OWHUART,&(internal_Buffer_tx[0]),len);
	HAL_SnglWireFullDuplex_EnableRTX(&OWHUART);
	*/
	  /* Enable DMA Channel Rx */
	LL_DMA_DisableChannel(DMA1, LL_DMA_CHANNEL_3);

	  /* Enable DMA Channel Tx */
	LL_DMA_DisableChannel(DMA1, LL_DMA_CHANNEL_2);
	  LL_DMA_ConfigAddresses(DMA1, LL_DMA_CHANNEL_2,
	                         (uint32_t)internal_Buffer_tx,
	                         LL_USART_DMA_GetRegAddr(OWHUART, LL_USART_DMA_REG_DATA_TRANSMIT),
	                         LL_DMA_GetDataTransferDirection(DMA1, LL_DMA_CHANNEL_2));
	  LL_DMA_SetDataLength(DMA1, LL_DMA_CHANNEL_2, len);

	  LL_DMA_ConfigAddresses(DMA1, LL_DMA_CHANNEL_3,
	                         LL_USART_DMA_GetRegAddr(OWHUART, LL_USART_DMA_REG_DATA_RECEIVE),
	                         (uint32_t)internal_Buffer_rx,
	                         LL_DMA_GetDataTransferDirection(DMA1, LL_DMA_CHANNEL_3));
	  LL_DMA_SetDataLength(DMA1, LL_DMA_CHANNEL_3, len);

	  /* Enable DMA transfer complete/error interrupts  */
	  LL_DMA_EnableIT_TC(DMA1, LL_DMA_CHANNEL_2);
	  LL_DMA_EnableIT_TE(DMA1, LL_DMA_CHANNEL_2);
	  LL_DMA_EnableIT_TC(DMA1, LL_DMA_CHANNEL_3);
	  LL_DMA_EnableIT_TE(DMA1, LL_DMA_CHANNEL_3);

	  /* Enable DMA RX Interrupt */
	  LL_USART_EnableDMAReq_RX(OWHUART);

	  /* Enable DMA TX Interrupt */
	  LL_USART_EnableDMAReq_TX(OWHUART);

	  /* Enable DMA Channel Rx */
	  LL_DMA_EnableChannel(DMA1, LL_DMA_CHANNEL_3);

	  /* Enable DMA Channel Tx */
	  LL_DMA_EnableChannel(DMA1, LL_DMA_CHANNEL_2);
}

void StateMachine(void)
{
    switch (state.Main_SM)
    {
	case 0: // start the Main_SM, reset device/test presence;
		OneWire_UARTInit(9600);
		internal_Buffer_rx[0]=0xf0;
		internal_Buffer_tx[0]=0xf0;
		state.Main_SM++;
		OW_RTX(1);
	break;
	case 1: // to check if the device exist or not.
		if (internal_Buffer_rx[0]==0xf0)
			onewire_callback.OnErr();
		else
			ROMStateMachine();
		state.Main_SM++;
	break;
	case 2:
		if (ROMStateMachine()==0)
		{
			state.Main_SM++;
			FunctionStateMachine();
		}
	break;
	case 3:
		if (FunctionStateMachine()==0)
		{
			LL_DMA_DisableChannel(DMA1, LL_DMA_CHANNEL_2);
			state.Main_SM++;
			onewire_callback.OnComplete();
		}
	//else
	break;
//	default:
    }
//    return ;
}

uint8_t ROMStateMachine(void)
{
    switch(state.ROM_SM)
    {
	case 0: // start the ROM_SM command by sendingROM_SMmmand
		OneWire_UARTInit(115200);
		/*for (uint8_t i=0;i<8;i++)
			internal_Buffer_tx[i]=((state.ROM_CmdCode>>i)&0x01)?0xff:0x00;
		//HAL_HalfDuplex_EnableTransmitter(&OWHUART);
		HAL_UART_Receive_IT(&OWHUART,&(internal_Buffer_rx[0]),8);
		HAL_UART_Transmit_IT(&OWHUART,&(internal_Buffer_tx[0]),8);
		//HAL_HalfDuplex_EnableReceiver(&OWHUART);
		 *
		 */
		OW_RTXByte(state.ROM_CmdCode);
		state.ROM_SM++;
	break;
	case 1: // continue by sending necessary Tx buffer
		if (state.ROM_TxCount!=0)
		{
			OW_SetRTXBuffer(state.ROM_TxBuffer, state.ROM_TxCount, OWD_TX);
			/*
			for (uint8_t i=0;i<state.ROM_TxCount;i++)
				for (uint8_t j=0;j<8;j++)
					internal_Buffer_tx[i*8+j]=((state.ROM_TxBuffer[i]>>j)&0x01)?0xff:0x00;
			//HAL_HalfDuplex_EnableTransmitter(&OWHUART);
			HAL_UART_Receive_IT(&OWHUART,&(internal_Buffer_rx[0]),state.ROM_TxCount*8);
			HAL_UART_Transmit_IT(&OWHUART,&(internal_Buffer_tx[0]),state.ROM_TxCount*8);
			//HAL_HalfDuplex_EnableReceiver(&OWHUART);			for (uint8_t i=0;i<state.ROM_TxCount;i++)
			OW_RTX(state.ROM_TxCount*8);
			*/
			state.ROM_SM++;
		}
		else
			if (state.ROM_RxCount!=0)
			{
				OW_SetRTXBuffer(state.ROM_RxBuffer, state.ROM_RxCount, OWD_RX);
				/*
				for (uint8_t i=0;i<=state.ROM_RxCount*8;i++)
					internal_Buffer_tx[i]=0xff;
				//HAL_HalfDuplex_EnableTransmitter(&OWHUART);
				//HAL_UART_Receive_IT(&OWHUART,&(internal_Buffer_rx[0]),state.ROM_RxCount*8);
				//HAL_UART_Transmit_IT(&OWHUART,&(internal_Buffer_tx[0]),state.ROM_RxCount*8);
				//HAL_HalfDuplex_EnableReceiver(&OWHUART);
				OW_RTX(state.ROM_RxCount*8);
				*/
				state.ROM_SM++;
			}
			else
				state.ROM_SM=0;
	break;
	case 2:
		/*
		if (state.ROM_RxCount!=0)
		{
			for (uint8_t i=0;i<state.ROM_RxCount;i++)
				for (uint8_t j=0;j<8;j++)
					state.ROM_RxCount[i]=(state.ROM_RxBuffer[i])+(((internal_Buffer_rx[i*8+j]==0xff)?0x01:0x00)<<j);
		}
		*/
		state.ROM_SM=0;
		break;
	}
    return state.ROM_SM;
}

uint8_t FunctionStateMachine(void)
{
    switch(state.Function_SM)
    {
	case 0:
		OneWire_UARTInit(115200);
		/*for (uint8_t i=0;i<8;i++)
			internal_Buffer_tx[i]=((state.Function_CmdCode>>i)&0x01)?0xff:0x00;
		//HAL_HalfDuplex_EnableTransmitter(&OWHUART);
		HAL_UART_Receive_IT(&OWHUART,&(internal_Buffer_rx[0]),8);
		HAL_UART_Transmit_IT(&OWHUART,&(internal_Buffer_tx[0]),8);
		//HAL_HalfDuplex_EnableReceiver(&OWHUART);*/
		OW_RTXByte(state.Function_CmdCode);
		state.Function_SM++;
		break;
	case 1: // continue by sending necessary Tx buffer
		if (state.Function_TxCount!=0)
		{
			OW_SetRTXBuffer(state.Function_TxBuffer, state.Function_TxCount, OWD_TX);
			/*
			for (uint8_t i=0;i<state.Function_TxCount;i++)
				for (uint8_t j=0;j<8;j++)
					internal_Buffer_tx[i*8+j]=((state.Function_TxBuffer[i]>>j)&0x01)?0xff:0x00;
			//HAL_HalfDuplex_EnableTransmitter(&OWHUART);
			//HAL_UART_Receive_IT(&OWHUART,&(internal_Buffer_rx[0]),state.Function_TxCount*8);
			//HAL_UART_Transmit_IT(&OWHUART,&(internal_Buffer_tx[0]),state.Function_TxCount*8);
			//HAL_HalfDuplex_EnableReceiver(&OWHUART);
			OW_RTX(state.Function_TxCount*8);
			*/
			state.Function_SM++;
		}
		else
			if (state.Function_RxCount!=0)
			{
				OW_SetRTXBuffer(state.Function_RxBuffer, state.Function_RxCount, OWD_RX);
				/*
				for (uint8_t i=0;i<=state.Function_RxCount*8;i++)
					internal_Buffer_tx[i]=0xff;
				//HAL_HalfDuplex_EnableTransmitter(&OWHUART);
				//HAL_UART_Receive_IT(&OWHUART,&(internal_Buffer_rx[0]),state.Function_RxCount*8);
				//HAL_UART_Transmit_IT(&OWHUART,&(internal_Buffer_tx[0]),state.Function_RxCount*8);
				//HAL_HalfDuplex_EnableReceiver(&OWHUART);
				OW_RTX(state.Function_RxCount*8);
				*/
				state.Function_SM++;
			}
			else
				state.Function_SM=0;
	break;
	case 2:
		/*
		if (state.Function_RxCount!=0)
		{
			for (uint8_t i=0;i<state.Function_RxCount;i++)
			{
				state.Function_RxBuffer[i]=0;
				for (uint8_t j=0;j<8;j++)
					state.Function_RxBuffer[i] |= (((internal_Buffer_rx[i*8+j]>=0xfc)?0x01:0x00)<<j);
			}
		}
		*/
		state.Function_SM=0;
		break;
	}
    return (state.Function_SM);
}



void test_ds18b20(void)
{
	static uint8_t statenum=0;
	static uint16_t tickcount=1;
	if (tickcount)
		tickcount--;
	else
	{
		switch (statenum)
		{
		case 0:
			TempRdy =0;
			OneWire_Init();
			OneWire_SetCallback(DS18x20_OnComplete, DS18x20_Error);
			OneWire_Execute(0xcc,0,0,0); /* skip rom phase */
			tickcount=100;
			statenum++;
			break;
		case 1:
			FunctionBuffer[0]=1;
			FunctionBuffer[1]=2;
			FunctionBuffer[2]=0x1f;
			OneWire_Execute(0xcc,0,0x4e,FunctionBuffer); /* skip rom phase set TH TL Config */
			tickcount=100;
			statenum++;
			break;
		case 2:
			OneWire_Execute(0xcc,0,0x44,0); /* start to Convert T */
			tickcount=1100;	// 1 tick per mS 1.1 Sec Delay
			statenum++;
			break;
		case 3:
			OneWire_Execute(0xcc,ROMBuffer,0xbe,FunctionBuffer); /* start to read configuration & result */
			tickcount=300;
			statenum++;
			break;
		case 4:
			TempRdy=1;
			statenum++;
			break;
		case 5:
			if(!TempRdy)
			{
				statenum=0;
				tickcount=10;
			}
		}

	}
}


void OneWire_Execute(uint8_t ROM_CmdCode,uint8_t* ROM_Buffer,uint8_t Function_CmdCode,uint8_t* Function_buffer)
{
    memset(&(state),0,sizeof(State));
    state.ROM_CmdCode=ROM_CmdCode;
    state.Function_CmdCode=Function_CmdCode;
    switch (ROM_CmdCode)
    {
        case 0x33:  // Read ROM
            state.ROM_RxBuffer=ROM_Buffer;
            state.ROM_RxCount=8; //8 byte
            break;
        case 0x55:  // Match ROM
            state.ROM_TxBuffer=ROM_Buffer;
            state.ROM_TxCount=8;
            break;
        case 0xf0: break; // Search ROM it might be too hard to implement you might need to refer to Chapter "C.3. Search ROM Command" in the pdf here:http://pdfserv.maximintegrated.com/en/an/AN937.pdf
        case 0xec: break; // Alarm Search it might be too hard to implement refer to http://pdfserv.maximintegrated.com/en/an/AN937.pdf if in need.
        case 0xcc: break; // Skip Rom just send the 0xcc only since the code is implement one-slave need.
    }
    switch (Function_CmdCode)
    {
        case 0x44: break; // Convert T need to transmit nothing or we can read a 0 while the temperature is in progress read a 1 while the temperature is done.
        case 0x4e:  // Write Scratchpad
            state.Function_TxBuffer=Function_buffer;
            state.Function_TxCount=3;
            break;
        case 0x48: break; // Copy Scratchpad need to transmit nothing
        case 0xbe:  // Read Scratchpad
            state.Function_RxBuffer=Function_buffer;
            state.Function_RxCount=9;
            break;
        case 0xb8: break; // Recall EEPROM return transmit status to master 0 for in progress and 1 is for done.
        case 0xb4: break; // read power supply only work for undetermined power supply status. so don't need to implement it
    }
    StateMachine();
}

#ifndef DIRECT_OWCALLBAK
/**
  * @brief  Function called from DMA1 IRQ Handler when Tx transfer is completed
  * @param  None
  * @retval None
  */
void DMA1_TransmitComplete_Callback(void)
{
  /* DMA Tx transfer completed */
	OneWire_TxCpltCallback();
}

/**
  * @brief  Function called from DMA1 IRQ Handler when Rx transfer is completed
  * @param  None
  * @retval None
  */
void DMA1_ReceiveComplete_Callback(void)
{
  /* DMA Rx transfer completed */
	OneWire_RxCpltCallback();
}
#endif

/**
  * @brief  Function called in case of error detected in USART IT Handler
  * @param  None
  * @retval None
  */
void USART_TransferError_Callback(void)
{
  /* Disable DMA1 Tx Channel */
  LL_DMA_DisableChannel(DMA1, LL_DMA_CHANNEL_2);

  /* Disable DMA1 Rx Channel */
  LL_DMA_DisableChannel(DMA1, LL_DMA_CHANNEL_3);

  /* Set Led to Fast Blinking mode to indicate error */
  //LED_Blinking(LED_BLINK_ERROR);
}


