/*
 * 18b20.h
 *
 *  Created on: Mar 19, 2020
 *      Author: roberto-mint
 */

#ifndef INC_18B20_H_
#define INC_18B20_H_
//#ifndef __DS18B20_H__
//#define __DS18B20_H__
//#include "usart.h"

extern volatile uint8_t TempRdy;


void OneWire_Init(void);
void OneWire_UARTInit(uint32_t baudRate);
void OneWire_Execute(uint8_t ROM_Command,uint8_t* ROM_Buffer,
                     uint8_t Function_Command,uint8_t* Function_buffer);
void test_ds18b20(void);
int readtempds18b20(uint8_t sensnum);
int readtempds18s20(uint8_t sensnum);
uint8_t DSCRC_OK(void);

/*
void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart);
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart);
void StateMachine(void);
void OneWire_SetCallback(void(*OnComplete)(void), void(*OnErr)(void));
uint8_t ROMStateMachine(void);
uint8_t FunctionStateMachine(void);
 */
//#end
#endif /* INC_18B20_H_ */
