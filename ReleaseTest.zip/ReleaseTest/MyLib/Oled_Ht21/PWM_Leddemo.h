/*
 * PWM_Leddemo.h
 *
 *  Created on: Mar 21, 2020
 *      Author: roberto-mint
 */

#ifndef PWM_LEDDEMO_H_
#define PWM_LEDDEMO_H_

void PWM_LED_Loop(void);
void PWM_LED_Init(void);

#endif /* PWM_LEDDEMO_H_ */
